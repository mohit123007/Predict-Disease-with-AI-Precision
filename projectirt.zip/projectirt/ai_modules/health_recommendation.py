def recommend_lifestyle(score: float):
    if score >= 80:
        return ["Keep up the good work", "Maintain current diet and exercise"]
    if score >= 50:
        return ["Increase exercise to 150 minutes/week", "Reduce processed sugar intake"]
    return ["Consult a physician", "Start supervised exercise program"]
