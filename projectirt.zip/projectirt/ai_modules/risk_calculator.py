def calculate_risk(features: dict) -> dict:
    """Simple risk scoring function for skeleton."""
    score = sum(float(v) for v in features.values() if _is_num(v))
    return {"risk_score": score, "risk_level": "moderate"}


def _is_num(v):
    try:
        float(v); return True
    except Exception:
        return False
