def suggest_specialist(symptoms: list):
    """Return specialist suggestions based on keywords in symptoms list."""
    text = ' '.join(symptoms).lower()
    if 'chest' in text or 'breath' in text:
        return ['Pulmonologist', 'Cardiologist']
    if 'skin' in text:
        return ['Dermatologist']
    return ['General Physician']
