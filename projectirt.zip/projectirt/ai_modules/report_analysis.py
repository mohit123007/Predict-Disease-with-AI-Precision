def parse_report_text(text: str):
    """Stub OCR/NLP for report parsing. Use pytesseract + spaCy for real impl."""
    sentences = [s.strip() for s in text.split('.') if s.strip()]
    return {"sentences": sentences[:20], "summary": sentences[0] if sentences else ''}
