def analyze_symptoms(symptoms_text: str):
    """Stub: analyze a free-text symptom description and return structured tokens.

    Replace with NLP parsing using spaCy or transformers.
    """
    tokens = [t for t in symptoms_text.split() if len(t) > 2]
    return {"tokens": tokens, "summary": ' '.join(tokens[:20])}
