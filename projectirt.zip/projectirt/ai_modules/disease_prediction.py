from typing import Dict, Any, List
import os

MODEL_PATH = "models/xgboost/model.joblib"


def _is_number(v: Any) -> bool:
    try:
        float(v)
        return True
    except Exception:
        return False


# Lazy model loading
_model = None


def _load_model():
    global _model
    if _model is not None:
        return _model
    try:
        if os.path.exists(MODEL_PATH):
            import joblib

            _model = joblib.load(MODEL_PATH)
            return _model
    except Exception:
        _model = None
    return None


def predict_tabular(features: Dict[str, Any]) -> Dict[str, Any]:
    """Try to use a saved model if available; otherwise fall back to deterministic stub."""
    model = _load_model()
    numeric_vals = []
    feature_vector = []
    # maintain deterministic ordering for stub
    keys = sorted(features.keys())
    for k in keys:
        v = features[k]
        feature_vector.append(float(v) if _is_number(v) else 0.0)
        if _is_number(v):
            numeric_vals.append(float(v))

    if model is not None:
        # model expected a 2D array
        try:
            prob = float(model.predict_proba([feature_vector])[0][1])
            disease = "diabetes" if prob >= 0.5 else "no_disease_detected"
            explanation = ["Model loaded from models/xgboost/model.joblib"]
            return {"disease": disease, "probability": round(prob, 4), "confidence": round(prob * 100, 2), "explanation": explanation}
        except Exception:
            # fallback to stub
            pass

    # stub behavior
    total = sum(numeric_vals) if numeric_vals else 0.0
    denom = max(1.0, len(numeric_vals) * 10.0)
    prob = min(0.99, max(0.01, total / denom))

    disease = "diabetes" if prob >= 0.5 else "no_disease_detected"

    ranked: List[tuple] = sorted(
        ((k, float(v)) for k, v in features.items() if _is_number(v)),
        key=lambda x: abs(x[1]),
        reverse=True,
    )
    explanation = [f"{k} influences prediction (value={v})" for k, v in ranked[:3]]

    return {
        "disease": disease,
        "probability": round(prob, 4),
        "confidence": round(prob * 100, 2),
        "explanation": explanation,
    }


def predict_image(image_bytes: bytes) -> Dict[str, Any]:
    """Stub image prediction — replace with CNN model inference.

    Returns a mock response."""
    return {"disease": "pneumonia", "probability": 0.72, "confidence": 72.0, "explanation_image": None}
