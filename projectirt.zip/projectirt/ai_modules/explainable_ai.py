def explain_tabular_prediction(model, features: dict):
    """Stub explanation function. Integrate SHAP for real explanations."""
    # Return top feature names and fake contributions
    contributions = [{"feature": k, "contribution": float(v) * 0.1 if _is_num(v) else 0.0} for k, v in features.items()]
    contributions = sorted(contributions, key=lambda x: abs(x['contribution']), reverse=True)[:5]
    return {"contributions": contributions}


def _is_num(v):
    try:
        float(v); return True
    except Exception:
        return False
