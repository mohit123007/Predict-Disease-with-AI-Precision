def compute_health_score(features: dict) -> float:
    """Compute a simple health score from normalized features."""
    vals = [float(v) for v in features.values() if _is_num(v)]
    if not vals:
        return 50.0
    score = max(0.0, min(100.0, 100.0 - sum(vals) / (len(vals) * 2)))
    return score


def _is_num(v):
    try:
        float(v); return True
    except Exception:
        return False
