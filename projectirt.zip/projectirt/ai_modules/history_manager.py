import json

def save_prediction(db_path: str, user: str, prediction: dict):
    """Simple JSON-based history save for skeleton. Replace with DB persistence."""
    entry = {"user": user, "prediction": prediction}
    with open(db_path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry) + "\n")
    return True
