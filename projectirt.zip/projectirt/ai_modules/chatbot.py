def reply_to_query(query: str):
    """Stub chatbot reply. Replace with transformer-based or retrieval+RAG approach."""
    return {"query": query, "reply": "This is a placeholder chatbot response. Consult a professional for medical advice."}
