from fastapi.testclient import TestClient
import backend.main as main

client = TestClient(main.app)


def test_tabular_prediction_flow():
    # Login to get token
    login_resp = client.post("/auth/login", json={"username": "test", "password": "test"})
    assert login_resp.status_code == 200
    data = login_resp.json()
    assert "access_token" in data
    token = data["access_token"]

    headers = {"Authorization": f"Bearer {token}"}

    # Call tabular prediction endpoint
    payload = {"features": {"age": 55, "bmi": 28.4, "glucose": 120}}
    resp = client.post("/predict/tabular", json=payload, headers=headers)
    assert resp.status_code == 200
    result = resp.json()
    assert "disease" in result
    assert "probability" in result
    assert 0.0 <= result["probability"] <= 1.0
