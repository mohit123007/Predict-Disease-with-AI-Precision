from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from pydantic import BaseModel
from typing import Dict, Any

from backend.services.auth_service import get_current_user
from backend.controllers.prediction_controller import predict_tabular_controller, predict_image_controller
from ai_modules.history_manager import save_prediction

router = APIRouter()


class TabularRequest(BaseModel):
    features: Dict[str, Any]


@router.post("/tabular")
async def predict_tabular_route(payload: TabularRequest, user=Depends(get_current_user)):
    """Endpoint for tabular data prediction. Expects JSON: {"features": {..}}"""
    try:
        result = predict_tabular_controller(payload.features)
        # save to simple history file for skeleton
        save_prediction('generated_reports/charts/predictions.log', user.get('sub') or user.get('username'), result)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/image")
async def predict_image_route(file: UploadFile = File(...), user=Depends(get_current_user)):
    """Endpoint for image prediction."""
    contents = await file.read()
    try:
        result = predict_image_controller(contents)
        save_prediction('generated_reports/charts/predictions.log', user.get('sub') or user.get('username'), result)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
