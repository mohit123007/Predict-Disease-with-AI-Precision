"""
Train a tiny example classifier and save to models/xgboost/model.joblib

Usage:
  python scripts/train_example_model.py

This is only for local development to generate a toy model to exercise the API.
"""
import os
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
import joblib

out_dir = "models/xgboost"
os.makedirs(out_dir, exist_ok=True)
X, y = make_classification(n_samples=200, n_features=10, n_informative=4, random_state=42)
model = LogisticRegression(max_iter=500)
model.fit(X, y)
joblib.dump(model, os.path.join(out_dir, "model.joblib"))
print("Saved example model to models/xgboost/model.joblib")
