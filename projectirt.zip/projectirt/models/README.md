Place trained models here.

Suggested layout:
- models/xgboost/model.joblib
- models/cnn/saved_model/
- models/nlp/transformer_model/
- models/scaler.pkl
- models/label_encoder.pkl

Do NOT commit large model binaries to the repository; use an artifact store or .gitignore them.
