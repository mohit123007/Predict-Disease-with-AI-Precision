// Minimal client-side helpers for the skeleton UI
document.addEventListener('submit', async (e) => {
  if (e.target && e.target.id === 'predictForm') {
    e.preventDefault();
    const form = e.target;
    const data = {
      features: {
        age: form.age.value,
        bmi: form.bmi.value,
        glucose: form.glucose.value,
      }
    };
    // For development, login first via /auth/login and store token in localStorage
    const token = localStorage.getItem('access_token') || '';
    const resp = await fetch('/predict/tabular', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify(data) });
    const json = await resp.json();
    document.getElementById('result').innerText = JSON.stringify(json, null, 2);
  }
});

// Simple login form handler
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const payload = { username: form.username.value, password: form.password.value };
    const resp = await fetch('/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (resp.ok) {
      const data = await resp.json();
      localStorage.setItem('access_token', data.access_token);
      alert('Logged in');
      window.location.href = '/dashboard.html';
    } else {
      alert('Login failed');
    }
  });
}
