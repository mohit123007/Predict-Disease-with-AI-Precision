# Medical Disease Prediction Platform (FastAPI MVP)

This repository is an MVP skeleton for an AI-powered medical disease prediction platform.

Quickstart (development):

1. Create and activate a Python virtual environment.
2. Install dependencies:
   pip install -r requirements.txt
3. (Optional) Train an example model for local testing:
   python scripts/train_example_model.py
4. Start the app:
   uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000

APIs:
- POST /auth/register  (username/password) -> create a user
- POST /auth/login     (username/password) -> returns JWT access_token
- POST /predict/tabular -> JSON {"features":{...}} with Authorization: Bearer <token>
- POST /predict/image  -> multipart/form-data image upload with Authorization

Notes:
- This skeleton uses a small SQLite store at backend/database/app.db to persist users.
- Model loading: ai_modules/disease_prediction.py will use models/xgboost/model.joblib if present.
- For production, review security (SECRET_KEY), HTTPS, storage of PHI, and legal/regulatory requirements.
